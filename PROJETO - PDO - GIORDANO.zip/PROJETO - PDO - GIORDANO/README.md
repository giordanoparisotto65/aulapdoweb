# PHP 7.4 with PDO SQLite Example

## NIX Packages

- php7.4
- php7.4 PDO extension
- sqlite3

## Running

Each time this example is run, a sqlite3 database is created or appended to. A single message is appended and all records are retrieved and rendered on the page.

## Thanks

Contents of this examples were taken from [this tutorial](https://www.if-not-true-then-false.com/2012/php-pdo-sqlite3-example/).