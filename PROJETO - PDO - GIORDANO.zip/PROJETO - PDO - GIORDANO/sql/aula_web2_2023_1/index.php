<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <a href="./view/UsuarioForm.php">Cadastrar </a><br>
    <a href="./view/UsuarioList.php">Listar </a>
	</body>
</html>